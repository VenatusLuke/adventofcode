inputfile = open("input.txt").readlines()
validpasswords = 0
for entry in range(0, len(inputfile)):
    keysfound = 0
    entrysplit = inputfile[entry].split(" ")
    entrymin = int(entrysplit[0].split("-")[0])
    entrymax = int(entrysplit[0].split("-")[1])
    entrykey = entrysplit[1]
    entrykey = entrykey[:-1]
    entryvalue = entrysplit[2]
    #for char in range(entrymin, entrymax):
    #    if entryvalue[char-1] == entrykey:
    #        keysfound += 1
    if entryvalue[entrymin-1] == entrykey:
        keysfound += 1
    if entryvalue[entrymax-1] == entrykey:
        keysfound += 1
    if keysfound == 1:
        print(entryvalue + " is valid! (" + entrykey + ", " + str(entrymin) + ", " + str(entrymax) + ")")
        validpasswords += 1
    else:
        print(entryvalue + " is not valid! (" + entrykey + ", "  + str(entrymin) + ", " + str(entrymax) + ")")
print("\nThere were " + str(validpasswords) + " valid passwords!")

inputfile = open("input.txt").readlines()
for u in range(0, len(inputfile)):
    for v in range(u+1, len(inputfile)):
        for a in range(v+1, len(inputfile)):
            if int(inputfile[u]) + int(inputfile[v]) + int(inputfile[a]) == 2020:
                print("The answer is: " + inputfile[u] + ", " + inputfile[v] + " and " + inputfile[a])
                print("The answer is: " + str(int(inputfile[u]) * int(inputfile[v]) * int(inputfile[a])))

